#include<unistd.h>
#include<string.h>
int main()
{
	char message[]="welcome to DS";
	write(1,message,strlen(message));
	return 0;
}
