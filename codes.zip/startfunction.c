#include<stdio.h>
#define start main
void start()
{
  printf("goodbye to python programming");
}
