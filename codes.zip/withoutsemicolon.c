#include<stdio.h>
int main()
{
	if (printf("product based MNC and service based MNC"))
	return 0;
}
